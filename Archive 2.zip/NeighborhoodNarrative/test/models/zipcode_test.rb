require 'test_helper'

class ZipcodeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

class Zipcode < ActiveRecord::Base
end

class UsersController < ApplicationController
	def home
	end
	def index
	end
	def about 
	end
	def search
	end
end